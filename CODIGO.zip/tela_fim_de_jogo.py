from pygame import *
from botoes import *
from config import *
from ppa import *


class TelaFimDeJogo:
    def __init__(self):

        self.fonte_jogo = font.Font('SpaceMono-Regular.ttf', 20)


        self.fundo = image.load('TELAPERDEU.png')
        self.fundo = transform.scale(self.fundo, (WIDTH, HEIGHT))


        self.botoes = []
        largura = 200
        altura = 60
        x = WIDTH / 2 - largura / 2
        y = 330


        self.botao_jogar_novamente = Botao(x, y, largura, altura, ROSA)
        self.botao_menu_principal = Botao(x, y + 80, largura, altura, ROSA)
        self.botao_sair = Botao(WIDTH / 2 - 120 / 2, y + 160, 120, altura, ROSA )
        self.botoes.append(self.botao_jogar_novamente)
        self.botoes.append(self.botao_menu_principal)
        self.botoes.append(self.botao_sair)


        self.jogar_novamente = self.fonte_jogo.render('Jogar novamente', True, BRANCO)
        self.menu_principal = self.fonte_jogo.render('Menu principal', True, BRANCO)
        self.sair = self.fonte_jogo.render('Sair', True, BRANCO)

    def desenha(self, window):

        window.blit(self.fundo, (0, 0))




        for botao in self.botoes:
            botao.desenha(window, False)


        window.blit(self.jogar_novamente, (
        WIDTH / 2 - self.jogar_novamente.get_width() / 2, HEIGHT / 2 - self.jogar_novamente.get_height() / 2 + 3))
        window.blit(self.menu_principal, (
        WIDTH / 2 - self.menu_principal.get_width() / 2, HEIGHT / 2 - self.menu_principal.get_height() / 2 + 80))
        window.blit(self.sair, (WIDTH / 2 - self.sair.get_width() / 2, HEIGHT / 2 - self.sair.get_height() / 2 + 160))


        display.update()

    def atualiza(self):

        for evento in event.get():
            if evento.type == QUIT:
                return 'sair'
            elif evento.type == MOUSEBUTTONUP:
                if evento.button == 1:
                    if self.botao_jogar_novamente.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'jogar'
                    elif self.botao_menu_principal.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'menu'
                    elif self.botao_sair.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'sair'
        return self