from pygame import *
from botoes import *
from config import *
from ppa import *

class TelaVenceuJogo:
    def __init__(self):


        # Carrega fonte
        self.fonte_jogo = font.Font ('SpaceMono-Regular.ttf', 20)

        # Cria mensagem de fim de jogo
        self.mensagem = fonte_jogo.render('Parabéns, você venceu o jogo!', True, BRANCO)

        self.fundo = image.load('ganh.png')
        self.fundo = transform.scale(self.fundo, (WIDTH, HEIGHT))

        # Cria dimensões dos botões
        self.botoes = []
        largura = 200
        altura = 60
        x = WIDTH/2 - largura/2
        y = 400

        # Cria botões
        self.botao_jogar_novamente = Botao(x, y, largura, altura, ROXOESCURO)
        self.botao_menu_principal = Botao(x, y + 80, largura, altura, ROXOESCURO)
        self.botao_sair = Botao(WIDTH/2 - 120/2, y + 160, 120, altura, ROXOESCURO)
        self.botoes.append(self.botao_jogar_novamente)
        self.botoes.append(self.botao_menu_principal)
        self.botoes.append(self.botao_sair)

        # Cria textos nos botões
        self.jogar_novamente = self.fonte_jogo.render('Jogar novamente', True, BRANCO)
        self.menu_principal = self.fonte_jogo.render('Menu principal', True, BRANCO)
        self.sair = self.fonte_jogo.render('Sair', True, BRANCO)


    def desenha(self, window):
        """ Desenha a tela de vitória"""
        # Desenha fundo na tela
        window.blit(self.fundo, (0, 0))

        # Desenha as mensagens na tela
        window.blit(self.mensagem, (WIDTH/2 - self.mensagem.get_width()/2, HEIGHT/2 - self.mensagem.get_height()/2 - 20))

        # Desenha botões
        for botao in self.botoes:
            botao.desenha(window, False)

        # Desenha textos do botões
        window.blit(self.jogar_novamente, (WIDTH/2 - self.jogar_novamente.get_width()/2, HEIGHT/2 - self.jogar_novamente.get_height()/2 + 70))
        window.blit(self.menu_principal, (WIDTH/2 - self.menu_principal.get_width()/2, HEIGHT/2 - self.menu_principal.get_height()/2 + 150))
        window.blit(self.sair, (WIDTH/2 - self.sair.get_width()/2, HEIGHT/2 - self.sair.get_height()/2 + 230))

        # Atualiza a tela
        display.update()

    def atualiza(self):
        """ Atualiza a tela de vitória"""
        # Check eventos
        for evento in event.get():
            if evento.type == QUIT:
                return 'sair'
            elif evento.type == MOUSEBUTTONUP:
                if evento.button == 1:
                    if self.botao_jogar_novamente.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'jogar'
                    elif self.botao_menu_principal.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'menu'
                    elif self.botao_sair.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'sair'
        return self