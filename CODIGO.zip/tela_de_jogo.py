from pygame import *
from botoes import *
from funcoes import *
from ppa import *


class TelaJogo:
    def __init__(self, perguntas):

        self.fonte_jogo = font.Font('SpaceMono-Regular.ttf', 25)


        self.imagem_fundo = image.load('FUNDO.png')


        self.timer, self.texto = 30, '30'.rjust(3)
        time.set_timer(USEREVENT, 1000)


        mixer.music.load('fundo.mp3')
        mixer.music.play(-1)
        self.success = success
        self.fail = fail
        self.win = win


        self.dicionario_classificado = classifica_nivel(perguntas)


        self.pontuacao = 0


        self.botoes_jogo = []
        self.botao_a = Botao(350, 300, 220, 100, ROXO)
        self.botao_b = Botao(600, 300, 220, 100, ROXO)
        self.botao_c = Botao(350, 420, 220, 100, ROXO)
        self.botao_d = Botao(600, 420, 220, 100, ROXO)
        self.botoes_jogo.append(self.botao_a)
        self.botoes_jogo.append(self.botao_b)
        self.botoes_jogo.append(self.botao_c)
        self.botoes_jogo.append(self.botao_d)



        self.sorteia_pergunta()


    def desenha(self, window):

        window.blit(self.imagem_fundo, (0, 0))


        window.blit(self.titulo, (WIDTH / 2 - 450, HEIGHT / 10 - self.titulo.get_height() / 2 + 100))


        for botao in self.botoes_jogo:
            botao.desenha(window, False)

        for txt in range(len(self.textos)):
            linhas = quebra_alternativa(self.textos[txt], self.l)
            desenha_linhas_pygame(linhas, self.fonte_jogo, (0, 0, 0), self.posicao[txt][0], self.posicao[txt][1] + 63)


        window.blit(self.pontuacao_do_jogador, (WIDTH / 2 - self.pontuacao_do_jogador.get_width() / 2 + 460,
                                                HEIGHT / 1.10 - self.pontuacao_do_jogador.get_height()))


        window.blit(self.nivel_atual, (
        WIDTH / 2 - self.nivel_atual.get_width() / 2 + 480, HEIGHT / 5 - self.nivel_atual.get_height() / 2))


        window.blit(self.fonte_jogo.render(self.texto, True, (255, 255, 255)), (32, 48))


        display.update()

    def sorteia_pergunta(self):


        self.nivel = define_nivel(self.pontuacao)



        self.questao_sorteada = questao_nivel(self.nivel, self.dicionario_classificado)


        self.titulo = self.fonte_jogo.render(self.questao_sorteada['titulo'], True, PRETO)


        self.l = 13
        self.opcoes = self.questao_sorteada['opcoes']
        self.textos = ['A: ' + self.opcoes['A'], 'B: ' + self.opcoes['B'], 'C: ' + self.opcoes['C'],
                       'D: ' + self.opcoes['D']]
        self.posicao = [(373, 263), (620, 263), (370, 387), (618, 387)]


        self.pontuacao_do_jogador = self.fonte_jogo.render("Pontuação: " + str(self.pontuacao), True, PRETO)


        self.cor_nivel = define_cor_nivel(self.nivel)


        self.nivel_atual = self.fonte_jogo.render(self.nivel, True, (self.cor_nivel))


        self.resposta = self.questao_sorteada['correta']


        self.indice = (self.dicionario_classificado[self.nivel].index(self.questao_sorteada))

    def atualiza(self):

        for evento in event.get():
            if evento.type == QUIT:
                return 'sair'

            elif evento.type == USEREVENT:
                self.timer -= 1
                self.texto = str(self.timer).rjust(3)
                if self.timer == 0:
                    mixer.music.pause()
                    self.fail.play()
                    return 'game_over'


            elif evento.type == MOUSEBUTTONUP:
                if evento.button == 1:
                    for resposta, botao in [('A', self.botao_a), ('B', self.botao_b), ('C', self.botao_c),
                                            ('D', self.botao_d)]:
                        if botao.verifica_clique(evento.pos[0], evento.pos[1]):
                            if resposta == self.resposta:
                                botao.desenha(window, True)
                                self.pontuacao += 1
                                self.success.play()


                                del (self.dicionario_classificado[self.nivel][self.indice])


                                self.nivel = define_nivel(self.pontuacao)


                                if self.nivel == 'Ganhou':
                                    mixer.music.pause()
                                    self.win.play()
                                    return 'venceu'


                                else:
                                    self.timer_texto = str(timer_nivel(self.nivel))
                                    self.timer, self.texto = timer_nivel(self.nivel), self.timer_texto.rjust(3)
                                    time.set_timer(USEREVENT, 1000)


                                    self.sorteia_pergunta()


                            else:
                                mixer.music.pause()
                                self.fail.play()
                                return 'game_over'
        return self