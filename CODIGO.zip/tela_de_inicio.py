from pygame import *
from botoes import *
from config import *


# Classe da tela de início
class TelaDeInicio:
    def __init__(self):


        self.fundo = image.load('comecoo.png')
        self.fundo = transform.scale(self.fundo, (WIDTH, HEIGHT))



        # Carrega fonte
        self.fonte_jogo = font.Font('SpaceMono-Regular.ttf', 20)

        # Cria dimensões dos botões
        self.botoes = []
        largura = 120
        altura = 60
        x = WIDTH / 2 - largura / 2
        y = 290

        # Cria botões
        self.botao_jogar = Botao(x, y, largura, altura, ROSA)
        self.botao_instrucoes = Botao(x, y + 100, largura, altura, ROSA)
        self.botao_sair = Botao(x, y + 200, largura, altura, ROSA)
        self.botoes.append(self.botao_jogar)
        self.botoes.append(self.botao_instrucoes)
        self.botoes.append(self.botao_sair)

        # Cria texto dos botões
        self.jogar = self.fonte_jogo.render('Jogar', True, BRANCO)
        self.instrucoes = self.fonte_jogo.render('Créditos', True, BRANCO)
        self.sair = self.fonte_jogo.render('Sair', True, BRANCO)

    def desenha(self, window):
        """Desenha a tela de início"""
        # Desenha fundo
        window.blit(self.fundo, (0, 0))

        # Desenha logo


        # Desenha botões
        for botao in self.botoes:
            botao.desenha(window, False)

        # Desenha textos do botões
        window.blit(self.jogar, (WIDTH / 2 - self.jogar.get_width() / 2, HEIGHT / 2 - self.jogar.get_height() / 1 + -23 ))
        window.blit(self.instrucoes,
                    (WIDTH / 2 - self.instrucoes.get_width() / 2, HEIGHT / 2 - self.instrucoes.get_height() / 2 + 60))
        window.blit(self.sair, (WIDTH / 2 - self.sair.get_width() / 2, HEIGHT / 2 - self.sair.get_height() / 2 + 160))

        # Atualiza a tela
        display.update()

    def atualiza(self):
        """Faz check de eventos"""
        # Check de eventos.
        for evento in event.get():
            if evento.type == QUIT:
                return 'sair'
            elif evento.type == MOUSEBUTTONUP:
                if evento.button == 1:
                    if self.botao_jogar.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'jogar'
                    elif self.botao_instrucoes.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'instrucoes'
                    elif self.botao_sair.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'sair'
        return self