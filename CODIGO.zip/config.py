# Dados gerais do jogo.
WIDTH = 1240# Largura da tela
HEIGHT = 720 # Altura da tela
FPS = 60 # Frames por segundo

#CORES
LARANJA = (238, 138, 111)
ROXO = (147,112,219)
ROXOESCURO = (75,0,130)
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
BEGE_FUNDO = (230, 226, 216)
VERDE = (0, 255, 0)
AMARELO = (255, 255, 0)
VERMELHO = (255, 0, 0)
CINZA = (192,192,192)
COR_TEMPO_RESPOSTA = (255, 255, 255)
ROSA = (255, 140, 237)