from pygame import *
from botoes import *
from config import *

class TelaDeInstrucoes:
    def __init__(self):
        # Carrega fonte
        self.fonte_jogo = font.Font ('SpaceMono-Regular.ttf', 20)

        self.imagem_fundo = image.load('credito.png')



        # Cria dimensão do botão
        largura = 120
        altura = 60
        x = WIDTH/2 - largura/2
        y = 550

        # Cria botão de voltar
        self.botao_voltar = Botao(x, y, largura, altura, PRETO)

        # Cria texto do botão
        self.voltar = self.fonte_jogo.render('Voltar', True, BRANCO)


    def desenha(self, window):

        window.blit(self.imagem_fundo, (0, 0))

        # Desenha regras


        # Desenha botão voltar
        self.botao_voltar.desenha(window, False)

        # Desenha texto dos botão
        window.blit(self.voltar, (WIDTH/2 - self.voltar.get_width()/2, HEIGHT/2 - self.voltar.get_height()/1 + 230))

        # Atualiza a tela
        display.update()

    def atualiza(self):
        """Atualiza a tela de instruções"""
        # Check eventos
        for evento in event.get():
            if evento.type == QUIT:
                return 'sair'
            if evento.type == MOUSEBUTTONUP:
                if evento.button == 1:
                    if self.botao_voltar.verifica_clique(evento.pos[0], evento.pos[1]):
                        return 'menu'
        return self