from pygame import *
from random import *

#  Inicia módulos do Pygame
init()


fonte_jogo = font.Font ('SpaceMono-Regular.ttf', 23)



mixer.music.load('fundo.mp3')
success = mixer.Sound('success.mp3')
fail = mixer.Sound('fail.mp3')
win = mixer.Sound('win.mp3')